package com.allandroidprojects.ecomsample.miscellaneous;


public interface ImageDownloadListener {
    void onUpdate(int progress);
}
